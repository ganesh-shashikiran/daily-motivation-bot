# Daily Motivation Bot

A simple and fun Python project that sends motivational quotes based on your current mood. It's a lightweight command-line program perfect for beginners learning conditional logic and dictionary usage in Python.

## Features

- Asks how you're feeling
- Gives you a quote that matches your mood
- Simple and beginner-friendly
- Great for daily inspiration!

## Technologies Used

- Python
- Random module
- Dictionary data structure

## How It Works

1. You type in your current mood (like `happy`, `sad`, `tired`, or `motivated`)
2. The bot selects a random quote from that mood category
3. It prints the quote as a motivational message

## Project Structure

```
daily-motivation-bot/
├── main.py            # Main Python script
└── README.md          # Project description
```

## How to Run

```bash
python main.py
```

## Example

```text
How are you feeling today? (happy/sad/tired/motivated): tired

Motivational Quote for You:
Even small steps forward count. Keep going!
```

## What I Learned

- How to use Python dictionaries and conditionals
- How to make interactive command-line tools
- Basic randomization with the `random` module

## Author

**Ganesh Shashikiran**  
B.Tech Student | Web & Python Enthusiast | Exploring AI One Step at a Time
