import random

quotes = {
    "happy": [
        "Keep smiling, it makes people wonder what you're up to!",
        "Happiness is contagious — spread it everywhere!"
    ],
    "sad": [
        "Tough times don’t last, but tough people do.",
        "Every storm runs out of rain. Stay strong."
    ],
    "tired": [
        "Rest if you must, but don’t quit.",
        "Even small steps forward count. Keep going!"
    ],
    "motivated": [
        "Dream big. Start small. Act now.",
        "The best way to get started is to quit talking and begin doing."
    ]
}

mood = input("How are you feeling today? (happy/sad/tired/motivated): ").lower()

if mood in quotes:
    print("\nMotivational Quote for You:")
    print(random.choice(quotes[mood]))
else:
    print("Sorry, I don't have quotes for that mood. Try again with happy, sad, tired, or motivated.")
